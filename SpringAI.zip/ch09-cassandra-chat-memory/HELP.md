# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Gradle documentation](https://docs.gradle.org)
* [Spring Boot Gradle Plugin Reference Guide](https://docs.spring.io/spring-boot/4.0.7/gradle-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/4.0.7/gradle-plugin/packaging-oci-image.html)
* [Cassandra](https://docs.spring.io/spring-boot/4.0.7/reference/data/nosql.html#data.nosql.cassandra)
* [Spring Configuration Processor](https://docs.spring.io/spring-boot/4.0.7/specification/configuration-metadata/annotation-processor.html)
* [Spring Data for Apache Cassandra](https://docs.spring.io/spring-boot/4.0.7/reference/data/nosql.html#data.nosql.cassandra)
* [Spring Boot DevTools](https://docs.spring.io/spring-boot/4.0.7/reference/using/devtools.html)
* [Cassandra Chat Memory Repository](https://docs.spring.io/spring-ai/reference/api/chat-memory.html)
* [JDBC Chat Memory Repository](https://docs.spring.io/spring-ai/reference/api/chat-memory.html)
* [Ollama](https://docs.spring.io/spring-ai/reference/api/chat/ollama-chat.html)
* [PGvector Vector Database](https://docs.spring.io/spring-ai/reference/api/vectordbs/pgvector.html)
* [Thymeleaf](https://docs.spring.io/spring-boot/4.0.7/reference/web/servlet.html#web.servlet.spring-mvc.template-engines)
* [Spring Web](https://docs.spring.io/spring-boot/4.0.7/reference/web/servlet.html)
* [Spring Reactive Web](https://docs.spring.io/spring-boot/4.0.7/reference/web/reactive.html)

### Guides
The following guides illustrate how to use some features concretely:

* [Spring Data for Apache Cassandra](https://spring.io/guides/gs/accessing-data-cassandra/)
* [Handling Form Submission](https://spring.io/guides/gs/handling-form-submission/)
* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)
* [Building a Reactive RESTful Web Service](https://spring.io/guides/gs/reactive-rest-service/)

### Additional Links
These additional references should also help you:

* [Gradle Build Scans – insights for your project's build](https://scans.gradle.com#gradle)

